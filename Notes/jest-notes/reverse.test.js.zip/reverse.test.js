var reverse = require('./reverse')

// expect().toBe()

test("returns given array in reverse order", function(){
    expect(reverse([1, 2, 3])).toEqual([3, 2, 1])  
})

// var arr1 = [3, 2 ,1]
// var arr2 = [3, 2, 1]