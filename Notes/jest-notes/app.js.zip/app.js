// Testing with Jest

    // TDD   vs   BDD
        // Test Driven Development  ( We use TDD )
            // - How a program should function

        // Behavior Driven Development
            // - How will a user interact with my program


// Expect to not be something
//     expect(1).toBe(1)
//     expect(1).not.toBe(0)

// // Checking Types
//     expect(null).toBeNull()
//     .toBeFalsy()
//     .toBeTruthy()