function reverse(arr){
    return arr.reverse()
}

module.exports = reverse